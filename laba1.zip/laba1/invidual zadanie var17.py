Python 3.12.5 (tags/v3.12.5:ff3bc82, Aug  6 2024, 20:45:27) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/Student/Desktop/lab1/individual zadanie 17.py
Положительные числа меньше 10: [1, 2, 3, 4, 5, 6, 7, 8, 9]
Произведение положительных чисел меньше 10: 362880
